from flask import Flask, render_template, request, jsonify, session

 
app = Flask(__name__)


import mysql.connector

app = Flask(__name__)

app.secret_key = 'pv'

# ======================= DB Functions ==============================

config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'face',
}


def insert_record(query, data):
    cnx = mysql.connector.connect(**config)
    crsr = cnx.cursor()
    crsr.execute(query, data)

    cnx.commit()
    crsr.close()
    cnx.close()


def update_record(query, data):
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    cursor.execute(query, data)

    cnx.commit()
    cursor.close()
    cnx.close()


def select_records(query):
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()
    cnx.close()
    return rows


def count_records(query):
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()
    cnx.close()
    return len(rows)

# ======================= Database Functions ==============================


# ======================= Common Functions ===============================

@app.route('/')
def index():
    return render_template('index.html')


# ----------- Student Register start -----------

@app.route('/register')
def register():
    return render_template('signup.html')


@app.route('/submitregister', methods=['POST'])
def submitregister():
    data = []
    fname = request.form['fname']
    data.append(fname)
    email = request.form['email']
    data.append(email)
    rollno = request.form['rollno']
    data.append(rollno)
    dob = request.form['dob']
    data.append(dob)
    course = request.form['course']
    data.append(course)
    semester = request.form['semester']
    data.append(semester)
    gender = request.form['gender']
    data.append(gender)
    phone = request.form['phone']
    data.append(phone)
    password = request.form['password']
    data.append(password)
    cpass = request.form['cpass']
    data.append(cpass)

    sql0="SELECT * from registration where email='"+email+"' " 
    data0=select_records(sql0)
    if len(data0)>0:
        return("Account already exists")
    
    else:
        
        if(password==cpass):
            
            sql = "INSERT INTO registration(fullname,email,rollno,dob,course,semester,gender,phone) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
            data = (fname, email, rollno, dob, course, semester, gender, phone)
            insert_record(sql, data)

            sql1 = "INSERT INTO login(email,password,usertype,userstatus) VALUES(%s,%s,%s,%s)"
            data1 = (email,password,0,1)
            insert_record(sql1, data1)

            return jsonify("Successfull")
        
        else:
            return jsonify("Password doesnot match")
        
        


    

    

# ----------- Student Register end -----------

#-----------------------Login---------------------



@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/submitlogin', methods=["POST", "GET"])

def submitlogin():
    data = []
    email = request.form['email']
    data.append(email)
    password = request.form['password']
    data.append(password)
    
    
    sql2 = "SELECT * from login where email='" + email + "' and password='" + password + "' "
    data2 = select_records(sql2)

    # print(type(data2[0][2]))
    
    if len(data2) > 0:
        usertype = data2[0][2]
        userstatus = data2[0][3]
        
        if usertype == 0:
            session['email'] = email
            return render_template('user/userpage.html')
            
    
        elif usertype == 1:
            session['email'] = email
            return render_template('admin/adminpage.html')
        
        else:
            return jsonify("unsuccessful login")
    else:
        return jsonify("invalid details")
    


def set_session(email):
    session['email'] = email


# ======================= Common Functions ends ===============================

if __name__ == '__main__':
    app.run(debug=True)
